import { CharValue } from './statuses'

export type KeyValue = CharValue | 'ENTER' | 'DELETE'
